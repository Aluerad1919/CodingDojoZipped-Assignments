from django.shortcuts import render, HttpResponse, redirect
from time import gmtime, localtime, strftime
 
    
# Create your views here.
def index(request):
    context = {
        "gmtime": strftime("%Y-%m-%d %H:%M %p", gmtime()),
        "localtime": strftime("%Y-%m-%d %H:%M %p", localtime())
    }
    return render(request,'index.html', context)