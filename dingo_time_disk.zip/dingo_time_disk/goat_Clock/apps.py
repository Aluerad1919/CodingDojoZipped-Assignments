from django.apps import AppConfig


class GoatClockConfig(AppConfig):
    name = 'goat_Clock'
