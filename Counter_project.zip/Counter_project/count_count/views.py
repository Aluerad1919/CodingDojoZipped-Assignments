from django.shortcuts import render, redirect

def index(request):
    if 'counting' in request.session:
        print('counting')
        request.session['counting'] += 1
    else:
        print("key 'counting' does NOT exist")
        request.session['counting'] = 0


    return render (request,'index.html')

def destroy(request):
    del request.session['counting']
    return redirect('/')



