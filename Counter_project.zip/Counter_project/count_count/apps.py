from django.apps import AppConfig


class CountCountConfig(AppConfig):
    name = 'count_count'
