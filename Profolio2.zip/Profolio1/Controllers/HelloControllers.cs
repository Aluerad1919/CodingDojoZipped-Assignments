using Microsoft.AspNetCore.Mvc;
namespace Profolio1.Controllers     
{
    public class HelloController : Controller   
    {
       
        [HttpGet("")]       
        public ViewResult Index()
        {
            return View();
        }
        [HttpGet("projects")]           
        public ViewResult Projects()
        {
            return View();
        }
        [HttpGet("contacts")]       
        public ViewResult Contacts()
        {
            return View();
        }
    }
}
