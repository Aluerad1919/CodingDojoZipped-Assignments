﻿using System;
using System.Collections.Generic;

namespace BoxingUnBoxing
{
    class Program
    {
        static void Main(string[] args)
        {
            List<object> junkDrawer = new List<object>();
            junkDrawer.Add(7);
            junkDrawer.Add(28);
            junkDrawer.Add(-1);
            junkDrawer.Add(true);
            junkDrawer.Add("chair");
            int counting = 0;
            for (int i = 0; i < junkDrawer.Count; i++)
            {
                if(junkDrawer[i] is int)
                {
                    int num = (int) junkDrawer[i];
                    counting = counting + num;
                }
            }
                Console.WriteLine(counting);
        }
    }
}
