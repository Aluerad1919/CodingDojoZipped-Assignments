import React, {useState,} from 'react'
import {Button} from './makeBox'
import {boxMaker} from './makeBox'

const Boxes = (props) => {
    const[box_dict, update_box_dict] = useState({
        the_box_arr:[],
        box_color: ''
    });
    return(
        <div>
            <h1>Add a color</h1>
            <boxMaker.Provider value={{box_dict, update_box_dict}}>
                <Button/>
            </boxMaker.Provider>
        </div>
    )
}

export default Boxes;