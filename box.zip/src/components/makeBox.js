import React, {useContext, createContext} from 'react'
import styles from './boxstyle.module.css'

export const boxMaker = createContext()
export const Button = e =>{
    const fromBoxMaker = useContext(boxMaker)
    const upDater= e =>{
        fromBoxMaker.box_dict.box_color = e.target.value
        fromBoxMaker.update_box_dict({
            ...fromBoxMaker.box_dict
        })
        
    }
    const Addcolor = e =>{
            fromBoxMaker.box_dict.the_box_arr.push(fromBoxMaker.box_dict.box_color)
            fromBoxMaker.box_dict.box_color = ''
            fromBoxMaker.update_box_dict({
                ...fromBoxMaker.box_dict
            })

    }
    const New_box_arr = fromBoxMaker.box_dict.the_box_arr.map((item, i)=>
        <div className={styles.box_dimension} style={{background: item}}></div>
    )

    return(
        <div>

            <input onChange={upDater} value={fromBoxMaker.box_dict.box_color} />
            <button onClick={Addcolor}>Add Color</button>
            {New_box_arr}
        </div>

    )
}