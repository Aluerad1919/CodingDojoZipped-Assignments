import logo from './logo.svg';
import './App.css';
import Boxes from './components/mainBox'

function App() {
  return (
    <div className="App">
      <Boxes/>
    </div>
  );
}

export default App;
