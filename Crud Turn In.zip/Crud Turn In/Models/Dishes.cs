using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; 

namespace Crudelicious.Models
{
    public class Dishes
    {
        [Key]
        public int DishId {get; set;}
        [Required]
        public string ChefName {get; set;}
        [Required]
        public string DishName {get; set;}
        [Required]
        [Range(0,Double.MaxValue)]
        public int CalCount {get; set;}
        [Required]
        public int TasteRate {get; set;}
        [Required]
        public string DishDesc {get; set;}
        public DateTime CreatedAt {get; set;} = DateTime.Now;
        public DateTime UpdatedAt {get; set;} = DateTime.Now;
    }
}