﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Crudelicious.Models;
using Microsoft.EntityFrameworkCore;

namespace Crudelicious.Controllers
{
    public class HomeController : Controller
    {
        private DishesContext _context;
        public HomeController(DishesContext context)
        {
            _context = context;
        }
        [HttpGet("")]
        public ViewResult Index()
        {
            // List<Dishes> AllDishes = _context.Dishes.ToList();
            ViewBag.NewPlates = _context.Dishes
                .OrderBy(dish => dish.CreatedAt)
                .ToList();
            return View();
        }

        [HttpGet("new")]
        public ViewResult New()
        {
            return View();
        }
        [HttpPost("MadeNewDish")]
        public IActionResult MadeNewDish(Dishes newDish)
        {
            if(ModelState.IsValid)
            {
                Console.WriteLine("Model worked");
                _context.Add(newDish);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            Console.WriteLine("Model didn't work");
            return RedirectToAction ("New");
        }
        [HttpGet("dish/{dishId}")]
        public ViewResult DishDetails(int dishId)
        {
          ViewBag.Dish = _context.Dishes
            .Find(dishId);
            return View();
        }
        [HttpGet("delete/{dishId}")]
        public IActionResult DeleteDish(int dishId)
        {
            var DishDelete = _context
            .Dishes
            .Find(dishId);

            _context.Dishes.Remove(DishDelete);
            _context.SaveChanges();
            Console.WriteLine("deleted");
            return RedirectToAction ("Index");
        }

        [HttpGet("edit/{dishId}")]
        public IActionResult Editdish(int dishId)
        {
            ViewBag.Dish= _context.Dishes
            .Find(dishId);
            return View();
        }

        [HttpPost("edit/{dishId}")]
        public IActionResult EditDish(Dishes newDish, int dishId)
        {
            if(ModelState.IsValid)
            {
                Dishes editDish = _context.Dishes.FirstOrDefault(Dish=> Dish.DishId==dishId);
                editDish.ChefName = newDish.ChefName;
                editDish.DishName = newDish.DishName;
                editDish.CalCount = newDish.CalCount;
                editDish.TasteRate = newDish.TasteRate;
                editDish.DishDesc = newDish.DishDesc;
                _context.SaveChanges();
                Console.WriteLine("Model worked");
                return RedirectToAction("Index");
            }
            Console.WriteLine("Model didn't work");
            return RedirectToAction ("EditDish");
        }
    }
}
