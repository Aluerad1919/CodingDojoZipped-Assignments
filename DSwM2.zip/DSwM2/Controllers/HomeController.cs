﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DSwM2.Models;

namespace DSwM2.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet("")]       
        public ViewResult Index()
        {
            return View();
        }
        // [HttpPost("result")]       
        // public IActionResult Post(string userName, string dojoLocation, string favLang, string comment)
        // {  
        //     ViewBag.Name = userName;
        //     ViewBag.Location = dojoLocation;
        //     ViewBag.Favorite = favLang;
        //     ViewBag.Comment = comment;
        
        //     return View();
        // }
        [HttpPost("survey")]
        public IActionResult Survey(Survey yourSurvey)
        {
            ViewBag.Name = yourSurvey.UserName;
            ViewBag.Location = yourSurvey.Dojo;
            ViewBag.Favorite = yourSurvey.FavLangauge;
            ViewBag.Comment = yourSurvey.Comments;
            return View();
        }
    }
}
