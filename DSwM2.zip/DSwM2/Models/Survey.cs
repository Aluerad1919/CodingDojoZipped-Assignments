using System;
namespace DSwM2
{

    public class Survey
    {
        public string UserName{ get; set;}
        public string Dojo{ get; set;}
        public string FavLangauge{ get; set;}
        public string Comments{ get; set;}
    }
}