﻿using System;
using System.Collections.Generic;
namespace HungryNinja
{
    class Food
    {
        public string Name {get;set;}
        public int Calories {get;set;}
        public bool IsSpicy {get;set;}
        public bool IsSweet {get;set;}
        public Food(string name, int cal, bool spice, bool sweet)
        {
            Name = name;
            Calories = cal;
            IsSpicy = spice;
            IsSweet = sweet;
        }
        public void Flavor()
        {
            if(IsSweet && IsSpicy)
            {
                Console.WriteLine("Is sweet and spicy");
            }
            else if(IsSpicy)
            {
                Console.WriteLine("Is spicy");
            }
            else if(IsSweet)
            {
                Console.WriteLine("Is sweet");
            }
        }
    }
    class Buffet
    {
        public List<Food> Menu;

        public Buffet()
        {
            Menu = new List<Food>()
            {
                new Food("Fire Ramen", 500, true, false),
                new Food("Orange chicken", 500, true, true),
                new Food("Chocolate Cake", 400, false, true),
                new Food("bacon", 150, false, false),
                new Food("Spicy bacon", 170, true, false),
                new Food("maple bacon", 190, false, true),
                new Food("tabasco lettuce leaf", 300, true, false)
            };
        }
        public Food Serve()
        {
            Random rnd = new Random();
            int eat = rnd.Next(0,Menu.Count);
            return Menu[eat];
        }

    }
    class Ninja
    {
        private int calorieIntake;
        public List<Food> FoodHisorty;

        public bool IsFull {get;set;}
        public Ninja()
        {
            calorieIntake= 0;
            FoodHisorty = new List<Food>();
            IsFull = false;
        }
        public void Eat(Food item)
        {
            if(calorieIntake < 1200)
            {
                calorieIntake += item.Calories;
                FoodHisorty.Add(item);
                item.Flavor();
                Console.WriteLine($"Om, Nom, nom on {item.Name}. current calories {calorieIntake}");
                
            }
            else
            {
                Console.WriteLine("you are full, stop eatting fatty!!");
            }

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Ninja bobDole = new Ninja();
            Buffet Ccs = new Buffet();
            bobDole.Eat(Ccs.Serve());

        }
    }
}
