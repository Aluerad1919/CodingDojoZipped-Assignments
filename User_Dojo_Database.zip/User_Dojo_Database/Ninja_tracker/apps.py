from django.apps import AppConfig


class NinjaTrackerConfig(AppConfig):
    name = 'Ninja_tracker'
