using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

public class Chefs{
    [Key]
    public int ChefId {get;set;}
    [Required]
    public string FirstName {get;set;}
    [Required]
    public string LastName {get;set;}
    [Required]
    public DateTime BirthDate {get;set;}
    public List<Dishes> DishesCreated {get;set;}
    public DateTime CreatedAt {get;set;} = DateTime.Now;
    public DateTime UpdateAt {get; set;} = DateTime.Now;
}