from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('post_dojo', views.add_dojo),
    path('post_ninja', views.add_ninja),
    path('destroy', views.delete),
]