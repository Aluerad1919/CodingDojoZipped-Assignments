from django.shortcuts import render, redirect
from .models import *

def index(request):
    context ={
        "Dojo_Db": Dojo.objects.all(),
        "Ninja_Db": Ninja.objects.all()
    }
    return render(request, 'index.html', context)

def add_dojo(request):
    Dojo.objects.create(
        dojo_name = request.POST['name_input'],
        dojo_city = request.POST['city_input'],
        dojo_state = request.POST['state_input']
    )
    return redirect('/')

def add_ninja(request):
    Ninja.objects.create(
        first_name = request.POST['ninja_firstname'],
        last_name = request.POST['ninja_lastname'],
        dojo = Dojo.objects.get(id=request.POST['ninja_home'])
    )
    return redirect('/')

def delete(request):
    Ninja.objects.filter(dojo=Dojo.objects.get(id=request.POST['assIsGrass'])).delete()
    Dojo.objects.get(id=request.POST['assIsGrass']).delete()
    return redirect('/')