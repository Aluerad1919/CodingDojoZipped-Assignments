from django.apps import AppConfig


class NinjaSurveyConfig(AppConfig):
    name = 'Ninja_Survey'
