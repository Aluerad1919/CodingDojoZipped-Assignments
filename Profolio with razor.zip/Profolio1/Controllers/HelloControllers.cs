using Microsoft.AspNetCore.Mvc;
namespace Profolio1.Controllers     
{
    public class HelloController : Controller   
    {
       
        [HttpGet]       
        [Route("")]     
        public ViewResult Index()
        {
            return View();
        }
        [HttpGet]       
        [Route("projects")]     
        public ViewResult Projects()
        {
            return View();
        }
        [HttpGet]       
        [Route("contacts")]     
        public ViewResult Contacts()
        {
            return View();
        }
    }
}
