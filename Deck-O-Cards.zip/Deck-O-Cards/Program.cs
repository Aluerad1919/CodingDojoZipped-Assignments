﻿using System;
using System.Collections.Generic;
namespace Deck_O_Cards
{
    class Card
    {
        public string StringVal {get;set;}
        public string Suit {get;set;}
        public int Val {get;set;}
        public Card(string sVal, string suit, int val)
        {
            StringVal = sVal;
            Suit = suit;
            Val = val;
        }
    }
    class Deck
    {
        public List<Card> Cards;
        public Deck()
        {
            List<string> suitlist = new List<string>
            {
                "Hearts",
                "Clubs",
                "Diamonds",
                "Spade",
            };
            List<string> sValList = new List<string>
            {
                "Ace",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "Jack",
                "Queen",
                "King",
            };
            Cards = new List<Card>(){};
            for(int i=0; i < suitlist.Count; i++)
            {
                for(int j=0; j < 13;j++)
                {
                    Card newcard = new Card(sValList[j],suitlist[i],j+1);
                    Cards.Add(newcard);
                }
            }
        }
        public Card Deal()
        {
            Card dealt = Cards[0];
            Cards.RemoveAt(0);
            return dealt;
        }
        public void ShuffleDicardPile()
        {
            Random rnd = new Random();
        }
        public void Shuffle()
        {
            Random rnd = new Random();
            int num= Cards.Count;
            while(num>1)
            {
                num--;
                int i = rnd.Next(num+1);
                var tempCard = Cards[i];
                Cards[i] = Cards[num];
                Cards[num] = tempCard;
            }
        }


    }
    class Player
    {
        public string Name {get;set;}
        public List<Card> Hand {get;set;}
        public Player(string name)
        {
            Name = name;
            Hand = new List<Card>();

        }
        public object Draw(Card drawcard)
        {
            Hand.Add(drawcard);
            return drawcard;
        }
        public void Discard(int val)
        {
            if(val > Hand.Count)
            {
                Console.WriteLine(" card doesn't exits");
            }
            Hand.RemoveAt(val);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Player bob = new Player("Bob Dole");
            Deck blah = new Deck();
            blah.Shuffle();
            bob.Draw(blah.Deal());
            Console.WriteLine(bob.Hand[0].StringVal);

        }
    }
}
