using System;
using System.ComponentModel.DataAnnotations;
namespace Dojodachi
{
    public class Stats
    {
        public int Fullness {get; set;}
        public int Happy {get; set;}
        public int Meals {get; set;}
        public int Energy {get; set;}
    }
}