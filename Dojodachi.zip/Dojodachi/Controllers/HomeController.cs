﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Dojodachi.Models;
using Microsoft.AspNetCore.Http;

namespace Dojodachi.Controllers
{
    public class HomeController : Controller
    {
       [HttpGet("")]
        public IActionResult Index()
        {
            if(HttpContext.Session.GetInt32("Fullness") == null)
            {
                HttpContext.Session.SetInt32("Fullness", 20);
                HttpContext.Session.SetInt32("Happiness", 20);
                HttpContext.Session.SetInt32("Meals", 3);
                HttpContext.Session.SetInt32("Energy", 50);
            }
            if(HttpContext.Session.GetInt32("Fullness")>= 100 && HttpContext.Session.GetInt32("Happiness") >= 100)
            {
                return RedirectToAction("Win");
            }
            if(HttpContext.Session.GetInt32("Fullness")<= 0 || HttpContext.Session.GetInt32("Happiness") <= 0)
            {
                return RedirectToAction("Lose");
            }
            ViewBag.full = HttpContext.Session.GetInt32("Fullness");
            ViewBag.happy = HttpContext.Session.GetInt32("Happiness");
            ViewBag.eat = HttpContext.Session.GetInt32("Meals");
            ViewBag.energy = HttpContext.Session.GetInt32("Energy");
            return View();
        }
        [HttpPost("eat")]
        public IActionResult Eat()
        {
            Console.WriteLine("eat");
            if((int)HttpContext.Session.GetInt32("Meals")>0)
            {

                Random rnd = new Random();
                HttpContext.Session.SetInt32("Meals", (int)HttpContext.Session.GetInt32("Meals") - 1);
                int nope = rnd.Next(0,21);
                if (nope <= 15)
                {
                    Console.WriteLine("eat and gain");
                    HttpContext.Session.SetInt32("Fullness", (int)HttpContext.Session.GetInt32("Fullness") + rnd.Next(5, 11)); 
                }
            }
            return RedirectToAction("Index");
        }
        [HttpPost("play")]
        public IActionResult Play()
        {
            if((int)HttpContext.Session.GetInt32("Energy")>0)
            {
                Random rnd = new Random();
                HttpContext.Session.SetInt32("Energy", (int)HttpContext.Session.GetInt32("Energy") - 5);
                int nope = rnd.Next(0,21);
                if (nope <= 15)
                {
                    HttpContext.Session.SetInt32("Happiness", (int)HttpContext.Session.GetInt32("Happiness") + rnd.Next(5, 11));
                }
            }
            return RedirectToAction("Index");
        }
        [HttpPost("work")]
        public IActionResult Work()
        {
            Random rnd = new Random();
            int moreMeals = rnd.Next(1,4);
            HttpContext.Session.SetInt32("Meals", (int)HttpContext.Session.GetInt32("Meals") + moreMeals);
            return RedirectToAction("Index");
        }
        [HttpPost("sleep")]
        public IActionResult Sleep()
        {
            HttpContext.Session.SetInt32("Fullness", (int)HttpContext.Session.GetInt32("Fullness") - 5);
            HttpContext.Session.SetInt32("Energy", (int)HttpContext.Session.GetInt32("Energy") + 15);
            HttpContext.Session.SetInt32("Happiness", (int)HttpContext.Session.GetInt32("Happiness") - 5);
            return RedirectToAction("Index");
        }
        [HttpGet("win")]
        public ViewResult Win()
        {
            return View();
        }
        [HttpGet("lose")]
        public ViewResult Lose()
        {
            return View();
        }
        [HttpPost("Restart")]
        public IActionResult Restart()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

    }
}
