﻿using System;
using System.Collections.Generic;
namespace CollectionPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] newArr3 = new int[9];
            bool[] newArr = new bool[10];
            string[] newArr2 = new string[] { "Tim", "Martin", "Nikki", "Sara" };
            for(int i = 0; i < newArr.Length; i++)
            {
                if( i % 2 != 0)
                {
                    newArr[i] = false;
                }
                else
                {
                    newArr[i] = true;
                }
                Console.WriteLine(newArr[i]);
            }

            List<string> iceCream = new List<string>();
            iceCream.Add("Vanilla");
            iceCream.Add("Chocolate");
            iceCream.Add("Strawberry");
            iceCream.Add("Blueberry");
            iceCream.Add("Green Tea");
            // Console.WriteLine($"There are {iceCream.Count} flavors");
            // Console.WriteLine($"The the third flavor is {iceCream[2]}");
            // iceCream.RemoveAt(2);
            // Console.WriteLine($"There are {iceCream.Count} flavors");

            Dictionary<string,string> profile = new Dictionary<string,string>();
            for (int i = 0; i < newArr2.Length; i++)
            {
                profile.Add(newArr2[i],iceCream[i]);
            }
            foreach(KeyValuePair<string,string> entry in profile)
            {
                Console.WriteLine(entry.Key + "-" + entry.Value);
            }


            
        }
    }
}
