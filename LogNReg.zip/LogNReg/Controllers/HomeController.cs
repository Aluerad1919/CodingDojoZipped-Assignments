﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using LogNReg.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace LogNReg.Controllers
{
    public class HomeController : Controller
    {
        private MyContext _context;
        public HomeController(MyContext context)
        {
            _context = context;
        }
        [HttpGet("")]
        public ViewResult Index()
        {
            return View();
        }

        [HttpPost("valid")]
        public IActionResult Validation(Users user)
        {
            if(ModelState.IsValid)
            {
                Console.WriteLine("entered reg model state question");
                if(_context.Users.Any(u => u.Email == user.Email))
                {
                    ModelState.AddModelError("Email", "Email already in use");
                    return View("Index");
                }
                PasswordHasher<Users> Hasher = new PasswordHasher<Users>();
                user.Password = Hasher.HashPassword(user, user.Password);
                _context.Add(user);
                Console.WriteLine("worked with validation register"+ _context);
                _context.SaveChanges();
                return RedirectToAction("Login", user);
            }
            Console.WriteLine("did not validate register");
            return View("Index");
        }

        [HttpPost("validLogin")]
        public IActionResult ValidLogin(LoginUser userSubmission)
        {
            if(ModelState.IsValid)
            {
                Console.WriteLine("enter model login validation " + userSubmission.Email);

                var userInDb = _context.Users.FirstOrDefault(u=>u.Email == userSubmission.Email);
                if(userInDb == null)
                {
                    Console.WriteLine("Make it noticable at line 56");
                    ModelState.AddModelError("Email", "Invalid Email/Password");
                    return View("Login");
                }
                var hasher= new PasswordHasher<LoginUser>();
                var result = hasher.VerifyHashedPassword(userSubmission, userInDb.Password, userSubmission.Password);
                if(result==0)
                {
                    Console.WriteLine("validation good");
                    return View ("Login");
                }

                    return RedirectToAction("Success");
            }
            Console.WriteLine("did not validate log in");
            return View("login");
        }

        [HttpGet("login")]
        public ViewResult Login()
        {
            return View();
        }

        [HttpGet("success")]
        public ViewResult Success()
        {
            return View();
        }
    }
}
