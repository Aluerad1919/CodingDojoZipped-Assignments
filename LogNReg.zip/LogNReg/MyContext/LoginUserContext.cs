using Microsoft.EntityFrameworkCore;
namespace LogNReg.Models
{
    public class MyContext : DbContext
    {
        public MyContext(DbContextOptions options) : base (options) {}
        public DbSet<Users> Users {get;set;}
    }
}