using Microsoft.AspNetCore.Mvc;
namespace TimeDisplay.Controllers     
{
    public class HelloController : Controller   
    {
       
        [HttpGet("")]       
        public ViewResult Index()
        {
            return View();
        }
    }
}