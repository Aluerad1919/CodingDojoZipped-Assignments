from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
import bcrypt

def login(request):
    return render(request, 'login.html')
    
def register(request):
    errors=Users.objects.count_Vald(request.POST)
    if len(errors) >0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    password = request.POST['pw_input']
    pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    new_user = Users.objects.create(
        first_name = request.POST['first_name_input'],
        last_name = request.POST['last_name_input'],
        email = request.POST['email_input'],
        password = pw_hash,
    )
    request.session['userid'] = new_user.id
    return redirect('/wishes')
    
def log(request):
    if request.POST['email_input'] == '':
        return redirect('/')
    if request.POST['pw_input'] == '':
        return redirect('/')
        
    errors=Users.objects.gateKeeper(request.POST)

    if len(errors) >0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')

    user = Users.objects.filter(email=request.POST['email_input'])
    if user:
        logged_user = user[0] 
        if bcrypt.checkpw(request.POST['pw_input'].encode(), logged_user.password.encode()):
            request.session['userid'] = logged_user.id
            return redirect('/wishes')
        return redirect("/")
    else:
        print("failed ")
        return redirect('/')
    return redirect('/')

def logout(request):
    request.session.clear()
    return redirect('/')

def remove(request, val):
    this_wish = Wishes.objects.get(id=val)
    this_wish.delete()
    return redirect('/wishes')
    
def wishes(request):
    context ={
        'logged_in': Users.objects.get(id=request.session['userid']),
        'users_db': Users.objects.all(),
        'wishes_db': Wishes.objects.all()
    }
    return render(request, 'wishes.html',context)

def edit (request, val):
    context={
        'logged_in': Users.objects.get(id=request.session['userid']),
        'this_wish': Wishes.objects.get(id=val)
    }
    return render(request, 'edit.html', context)

def new_wish(request):
    context={
        'logged_in': Users.objects.get(id=request.session['userid']),
    }
    return render(request, 'new.html', context)

def stats(request,val):
    this_guy = Users.objects.get(id=request.session['userid'])
    grantless = Wishes.objects.filter(granted=False)
    context ={
        'logged_in': Users.objects.get(id=request.session['userid']),
        'wishes_db': Wishes.objects.all(),
        'wish_granted': Wishes.objects.filter(granted=True),
        'not_granted': Wishes.objects.filter(granted=False, wished_by=this_guy),
        'did_grant': Wishes.objects.filter(granted=True, wished_by=this_guy)
    }
    return render(request, 'stats.html', context)

def create_a_wish(request):
    errors = Wishes.objects.secretary_check(request.POST)
    if len(errors) >0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/new_wish')
    Wishes.objects.create(
        item= request.POST['item_input'],
        description= request.POST['desc_input'],
        wished_by = Users.objects.get(id=request.session['userid'])
    )
    return redirect('/wishes')

def grant(request, val):
    this_wish = Wishes.objects.get(id=val)
    this_wish.granted = True
    this_wish.save()
    return redirect ('/wishes')

def edit_wish(request, val):
    this_wish=Wishes.objects.get(id=val)
    errors = Wishes.objects.secretary_check(request.POST)
    if len(errors) >0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f'/edit/{val}')
    else:
        if "item_input" != "":
            this_wish.item=request.POST['item_input']
            this_wish.save()
        if "desc_input" != "":
            this_wish.description=request.POST['desc_input']
            this_wish.save()
    return redirect('/wishes')

def likes(request, val):
    this_wish=Wishes.objects.get(id=val)
    da_guy=Users.objects.get(id=request.session['userid'])
    this_wish.liked_by.add(da_guy)
    return redirect('/wishes')