from datetime import datetime,timedelta
today = datetime.today().strptime("30 Nov 2000",'%Y-%m-%d')
ago = today - timedelta(years=13)
print(today)