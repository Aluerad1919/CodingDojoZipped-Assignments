﻿using System;

namespace Human
{
    class Human
    {
        public string Name {get;set;}
        public int Strength {get;set;}
        public int Intelligence {get;set;}
        public int Dexterity {get;set;}
        protected internal int Health {get;set;}

        public int healthPoints()
        {
            return Health; 
        }
        public Human(string name)
        {
            Name = name;
            Strength = 3;
            Intelligence = 3;
            Dexterity = 3;
            Health = 100;
        }
        public Human(string name, int str, int intell, int dex, int hp)
        {
            Name = name;
            Strength = str;
            Intelligence = intell;
            Dexterity = dex;
            Health = hp;
        }
        public virtual int Attack(Human target)
        {
            int hit = Strength * 5;
            target.Health = target.Health - hit;
            return target.Health;
        }
        public override string ToString()
        {
            return $"{Name}, has {Health}";
        }
    }
    class Ninja : Human
    {
        public Ninja(string name) : base(name)
        {
            Dexterity = 175;
        }
        public override int Attack(Human target)
        {
            int hit = Dexterity * 5;
            Random rnd = new Random();
            int chance = rnd.Next(10);
            if(chance <= 2)
            {
                hit+=10;
            }
            target.Health = target.Health - hit;
            return target.Health;
        }
        public void Steal(Human target)
        {
            target.Health -= 5;
            Health += 5;

        }
    }
    class Wizard : Human
    {
        public Wizard(string name) : base(name)
        {
            Intelligence = 25;
            Health = 50;
        }
        public override int Attack(Human target)
        {
            int hit = Intelligence * 5;
            Health += hit/2;
            target.Health = target.Health - hit;
            return target.Health;
        }
        public void Heal(Human target)
        {
            var healthSpell = Intelligence * 10;
            target.Health += healthSpell;
        }
    }
    class Samurai : Human
    {
        
        public Samurai(string name) : base(name)
        {
            Health = 200;
        }
        public override int Attack(Human target)
        {
            if(target.Health < 50)
            {
                target.Health = 0;
            }
            int hit = Strength * 5;
            target.Health = target.Health - hit;
            return target.Health;
        }
        public void Meditate()
        {
            Health = 200;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Ninja bob = new Ninja("Bob");
            Wizard george = new Wizard("George");
            Samurai jack = new Samurai("Jack");
            bob.Attack(george);
            Console.WriteLine(george.Health);
            george.Heal(george);
            Console.WriteLine(george.Health);

           
        }

    }
}
