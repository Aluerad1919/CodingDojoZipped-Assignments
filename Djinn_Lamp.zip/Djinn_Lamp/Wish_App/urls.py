from django.urls import path, include
from.import views, models

urlpatterns = [
    path('', views.login),
    path('register', views.register),
    path('log', views.log),
    path('wishes', views.wishes),
    path('logout', views.logout),
    path('remove/<int:val>', views.remove),
    path('edit/<int:val>', views.edit),
    path('create_a_wish', views.create_a_wish),
    path('new_wish', views.new_wish),
    path('grant/<int:val>', views.grant),
    path('edit_wish/<int:val>', views.edit_wish),
    path('stats/<int:val>', views.stats),
    path('like/<int:val>', views.likes),
]