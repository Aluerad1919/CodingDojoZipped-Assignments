from django.urls import path, include
from.import views, models

urlpatterns = [
    path('', views.loginReg),
    path('register', views.register),
    path('log', views.log),
    path('logout', views.logout),
    path('book', views.book),
    path('destroy/<int:val>', views.delete),
    path('details/<int:val>', views.details),
    path('create', views.create),
    path('edit/<int:val>', views.edit),
    path('add_fav/<int:val>', views.favoriting),
]