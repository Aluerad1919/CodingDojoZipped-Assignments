from django.apps import AppConfig


class FavReadsConfig(AppConfig):
    name = 'Fav_reads'
