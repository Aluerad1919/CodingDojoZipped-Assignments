from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
import bcrypt

def loginReg(request):
    return render(request, 'login.html')
    
def register(request):
    errors=Users.objects.count_Vald(request.POST)
    if len(errors) >0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    password = request.POST['pw_input']
    pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    new_user = Users.objects.create(
        first_name = request.POST['first_name_input'],
        last_name = request.POST['last_name_input'],
        email = request.POST['email_input'],
        password = pw_hash,
        birthdate = request.POST['bday_input']
    )
    request.session['userid'] = new_user.id
    return redirect('/book')

def log(request):
    errors=Users.objects.gateKeeper(request.POST)
    if len(errors) >0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    user = Users.objects.filter(email=request.POST['email_input'])
    if user:
        logged_user = user[0] 
        if bcrypt.checkpw(request.POST['pw_input'].encode(), logged_user.password.encode()):
            request.session['userid'] = logged_user.id
            return redirect('/book')
        return redirect("/")
    else:
        print("failed ")
        return redirect('/')
    return redirect('/')

def logout(request):
    request.session.clear()
    return redirect('/')

def delete(request, val):
    this_book = Books.objects.get(id=val)
    this_book.delete()
    return redirect('/book')
    
def book(request):
    context ={
        'logged_in': Users.objects.get(id=request.session['userid']),
        'users_db': Users.objects.all(),
        'books_db':Books.objects.all()
    }
    return render(request,'book.html', context)

def details(request, val):
    context ={
        'logged_in': Users.objects.get(id=request.session['userid']),
        'this_book':Books.objects.get(id=val),
    }
    return render(request,'details.html', context)

def create(request):
    errors = Books.objects.dewy_validate(request.POST)
    if len(errors) >0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/book')
    Books.objects.create(
        title = request.POST['title_input'],
        description = request.POST['desc_input'],
        uploaded_by = Users.objects.get(id=request.session['userid'])
    )
    return redirect('/book')

def favoriting(request, val):
    this_book=Books.objects.get(id=val)
    da_guy=Users.objects.get(id=request.session['userid'])
    this_book.liked_by.add(da_guy)
    return redirect('/book')

def edit(request, val):
    this_book=Books.objects.get(id=val)
    errors = Books.objects.dewy_validate(request.POST)
    if len(errors) >0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f'/details/{val}')
    else:
        if "title-input" != "":
            this_book.title=request.POST['title_input']
            this_book.save()
        if "desc_input" != "":
            this_book.desc=request.POST['desc_input']
            this_book.save()
    return redirect(f'/details/{val}')