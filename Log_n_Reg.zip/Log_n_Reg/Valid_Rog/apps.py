from django.apps import AppConfig


class ValidRogConfig(AppConfig):
    name = 'Valid_Rog'
