﻿using System;
using System.Collections.Generic;
namespace Puzzles
{
    class Program
    {
        public static int[] RandomArray()
        {
            Random rnd = new Random();
            int[] randArr = new int[10];
            int max = 0;
            int min = 25;
            int sum = 0;
            for (int i = 0; i < randArr.Length; i++)
            {
                randArr[i] = rnd.Next(5, 26); ;
                if (randArr[i] > max)
                {
                    max = randArr[i];
                }
                if (randArr[i] < min)
                {
                    min = randArr[i];
                }
                Console.WriteLine(randArr[i]);
                sum += randArr[i];
            }
            Console.WriteLine($"Max = {max} Min = {min}, Sum = {sum} ");
            return randArr;

        }
        public static string TossCoin()
        {
            Console.WriteLine("Tossing a Coin!");
            Random rnd = new Random();
            int num = rnd.Next(1, 7);
            string result = "Tails";
            if (num % 2 == 0)
            {
                Console.WriteLine("Heads");
                result = "Heads";
                return result;
            }
            else
            {
                Console.WriteLine("Tails");
                return result;
            }
        }
        public static double TossMultipleCoins(int num)
        {
            int nums = num;
            double countWin = 0;
            double count = 0;
            for (int i = 1; i <= nums; i++)
            {
                count++;
                if (TossCoin() == "Heads")
                {
                    countWin++;
                }
            }
            Console.WriteLine($"count {count}, countWin {countWin}");
            return countWin / count;
        }
        public static List<string> Names()
        {
            List<string> names = new List<string>();
            List<string> newNames = new List<string>();
            names.Add("Todd");
            names.Add("Tiffany");
            names.Add("Charlie");
            names.Add("Geneva");
            names.Add("Sydney");
            Random rnd = new Random();
            int n = names.Count;
            while (n > 1)
            {
                n--;
                int k = rnd.Next(n + 1);
                string value = names[k];
                names[k] = names[n];
                names[n] = value;
            }
            for (int i = 0; i < names.Count; i++)
            {
                Console.WriteLine(names[i]);
                if(names[i].Length >= 5)
                {
                    newNames.Add(names[i]);
                }
            }
            Console.WriteLine("Names greater than 5 characters");
            for (int i = 0; i < newNames.Count; i++)
            {
                Console.WriteLine(newNames[i]);
            }
            return newNames;
        }

        static void Main(string[] args)
        {
            // RandomArray();
            // TossCoin();
            // TossMultipleCoins(2);
            Names();
        }
    }
}
