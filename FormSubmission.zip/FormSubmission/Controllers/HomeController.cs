﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FormSubmission.Models;

namespace FormSubmission.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet("")]
        public ViewResult Index()
        {
            return View();
        }
        
        [HttpPost("submission")]
        public IActionResult Submission(User newuser)
        {
            if(ModelState.IsValid)
            {
                Console.WriteLine("Model worked");
                return RedirectToAction("Submitted", newuser);
            }
                Console.WriteLine("Model did not worked");
                return View("Index");
        }
        [HttpGet("submitted")]
        public IActionResult Submitted(User newuser)
        {
            return View(newuser);
        }
    }
}
