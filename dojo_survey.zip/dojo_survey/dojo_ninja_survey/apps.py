from django.apps import AppConfig


class DojoNinjaSurveyConfig(AppConfig):
    name = 'dojo_ninja_survey'
