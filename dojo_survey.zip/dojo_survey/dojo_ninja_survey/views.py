from django.shortcuts import render, redirect

def index(request):
    return render(request, 'index.html')

def created_ninja(request):
    context = {
        'new_ninja_name' : request.POST['name'],
        'new_ninja_email' : request.POST['email'],
        'home_dojo' : request.POST['city'],
        'weapon_preferance' : request.POST['langauge'],
        'last_words' : request.POST['comments'],
    }
    return render(request, 'made_a_ninja.html', context)

