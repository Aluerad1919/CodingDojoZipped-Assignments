﻿using System;
using System.Collections.Generic;

namespace Basic13
{
    class Program
    {
        public static void PrintNumbers()
        {
            // Print all of the integers from 1 to 255.
            for(int i = 0; i <=255;i++)
            {
                Console.WriteLine(i);
            }
        }
        public static void PrintOdds()
        {
            // Print all of the odd integers from 1 to 255.
            for(int i = 1; i<=255; i+=2 )
            {
                Console.WriteLine(i);
            }
        }
           static void PrintSum()
        {
            int sum = 0;
            for(int i = 0; i <=255;i++)
            {
                sum += i;
            }
                Console.WriteLine(sum);
        }
        public static void LoopArray(int[] num)
        {
            for(int i = 0; i < num.Length; i++)
            {
                Console.WriteLine(num[i]);
            }
        }
        public static int FindMax(int[] num)
        {
            int max = num[0];
            for(int i = 0; i < num.Length; i++)
            {
                if ( num[i] > max)
                {
                    max = num[i];
                }
            }
            Console.WriteLine(max);
            return max;
        }
        public static void GetAverage(int[] num)
        {
            int arrAvg = 0;
            for(int i = 0; i < num.Length; i++)
            {
                arrAvg += num[i];
            }
            Console.WriteLine($"total: {arrAvg}, Array length: {num.Length}, Average of: {arrAvg/num.Length}");
        }
        public static int[] OddArray()
        {
            int[] newArr= new int[127];
            for(int i = 1; i<=255; i+=2 )
            {
                newArr[i] = i;
            }
            return newArr;
        }
        public static int GreaterThanY(int[] num, int y)
        {
            int sum = 0;
            for(int i = 0; i < num.Length;i++)
            {
                if(num[i]>y)
                {
                    sum ++;
                }
            }
                Console.WriteLine(sum);
                return sum;
        }
        public static void SquareArrayValues(int[] num)
        {
            for(int i = 0; i < num.Length; i++)
            {
                num[i] = num[i] * num[i];
                Console.WriteLine(num[i]);
            }
        }
        public static void EliminateNegatives(int[] num)
        {
            for(int i = 0; i < num.Length; i++)
            {
                if(num[i]< 0)
                {
                    num[i]=0;
                }
                
                Console.WriteLine(num[i]);
            }
        }
        public static void MinMaxAverage(int[] num)
        {
            int max = num[0];
            int min = num[0];
            int sum = 0;
            for(int i = 0; i < num.Length; i++)
            {
                if ( num[i] > max)
                {
                    max = num[i];
                }
                if ( num[i] < min)
                {
                    min = num[i];
                }
                sum += num[i];
            }
            Console.WriteLine($"Max={max}, Min={min}, Avg={sum/num.Length}");
        }
        public static void ShiftValues(int[] num)
        {
            
            for(int i = 0; i < num.Length; i++)
            {
                if (num[i] == num[num.Length-1])
                {
                    num[i] = 0;
                    Console.WriteLine(num[i]);
                    break;
                }
                int temp = num[i+1];
                num[i] = temp;
                Console.WriteLine(num[i]);
            }
        }
        public static object[] NumToString(int[] num)
        {
            object[] newNum = new object[num.Length];
            for(int i = 0; i < num.Length; i++)
            {
                if (num[i]<0)
                {
                    newNum[i] = "Dojo";
                }
                else
                {
                    newNum[i] = num[i];
                }
                Console.WriteLine(newNum[i]);
            }
            return newNum;
        }
        static void Main(string[] args)
        {
            int[] numArr= new int[] {1,9,2,8,2,8,3,7,5,6};
            int[] numArr2 = new int[] {1,9,-3,6,-5,7,-9};
            int[] numArr3 = new int[] {1,9,-3,};
            // PrintNumbers();
            // PrintOdds();
            // PrintSum();
            // LoopArray(numArr);
            // FindMax(numArr);
            // GetAverage(numArr);
            // OddArray();
            // GreaterThanY(numArr, 4);
            // SquareArrayValues(numArr);
            // EliminateNegatives(numArr2);
            // MinMaxAverage(numArr);
            // ShiftValues(numArr3);
            NumToString(numArr3);
        }
    }
}
