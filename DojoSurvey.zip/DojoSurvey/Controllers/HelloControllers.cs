using Microsoft.AspNetCore.Mvc;
namespace DojoSurvey.Controllers     
{
    public class HelloController : Controller   
    {
       
        [HttpGet("")]       
        public ViewResult Index()
        {
            return View();
        }
        [HttpPost("post")]       
        public IActionResult Post(string userName, string dojoLocation, string favLang, string comment)
        {  
            ViewBag.Name = userName;
            ViewBag.Location = dojoLocation;
            ViewBag.Favorite = favLang;
            ViewBag.Comment = comment;
        
            return View();
        }
    }
}
