from django.apps import AppConfig


class TvLineUpConfig(AppConfig):
    name = 'TV_Line_UP'
