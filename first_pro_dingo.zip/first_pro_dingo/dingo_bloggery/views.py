from django.shortcuts import render, HttpResponse, redirect
def root(request):
    print("placeholder")
    return render(request, '/blogs')

def index(request):
    return HttpResponse("placeholder to later display a list of all blogs")

def new(request):
    return HttpResponse("placeholder for new blogs")

def create(request):
    return redirect('/blogs')

def show(request, number):
    # print("placeholder display blog number: {number}"
    return HttpResponse(f'Placeholder for blog {number}')

def edit(request, number):
    return HttpResponse(f'Placeholder for blog number {number}')

def destory(request, number):
    return HttpResponse(f'Placeholder for blog number {number}')

    

# Create your views here.
