from django.apps import AppConfig


class DingoBloggeryConfig(AppConfig):
    name = 'dingo_bloggery'
