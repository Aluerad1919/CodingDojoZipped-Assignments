﻿using System;

namespace Human
{
    class Human
    {
        public string Name {get;set;}
        public int Strength {get;set;}
        public int Intelligence {get;set;}
        public int Dexterity {get;set;}
        private int Health {get;set;}

        public int healthPoints()
        {
            return Health; 
        }
        public Human(string name)
        {
            Name = name;
            Strength = 3;
            Intelligence = 3;
            Dexterity = 3;
            Health = 100;
        }
        public Human(string name, int str, int intell, int dex, int hp)
        {
            Name = name;
            Strength = str;
            Intelligence = intell;
            Dexterity = dex;
            Health = hp;
        }
        public int Attack(Human target)
        {
            int hit = Strength * 5;
            target.Health = target.Health - hit;
            return target.Health;
        }
        public override string ToString()
        {
            return $"{Name}, has {Health}";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
           Human bob = new Human("Bob dole");
           Human orc = new Human("not an orc", 5,5,5,500);
           bob.healthPoints();
           Console.WriteLine(bob);
           bob.Attack(orc);
           Console.WriteLine(orc);

           Console.WriteLine(orc.healthPoints());
           
        }

    }
}
