﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ViewModelFun2.Models;

namespace ViewModelFun.Controllers
{
    public class HomeController : Controller
    {
       [HttpGet("")]
        public IActionResult Index()
        {
            string[] names = new string[]
            {
            "Sally", "Billy", "Joey", "Moose"
            };
            return View(names);
        }
        [HttpGet("numbers")]
        public IActionResult Numbers()
        {
            int[] nums = new int[]
            {
                12,3,4,5,63,23,
            };
            return View(nums);
        }
        [HttpGet("Users")]
       public IActionResult Users()
       {
           Users someUser = new Users()
           {
               FirstName = "Bob",
               LastName = "Dole"
           };
           Users someUser2 = new Users()
           {
               FirstName = "Sue",
               LastName = "Bert"
           };
           Users someUser3 = new Users()
           {
               FirstName = "Terra",
               LastName = "Woods"
           };
           List<Users> viewModel = new List<Users>()
           {
               someUser, someUser2, someUser3
           };

           return View(viewModel);
       }
       [HttpGet("User")]
       public IActionResult oneUser()
       {
           Users someUser = new Users()
           {
               FirstName = "Bob",
               LastName = "Dole"
           };
           return View(someUser);
       }
    }
}
