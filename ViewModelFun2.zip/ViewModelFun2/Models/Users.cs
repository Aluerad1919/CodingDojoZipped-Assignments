    
using System;

namespace ViewModelFun2.Models
{
    public class Users
    {
        public string FirstName {get;set;}
        public string LastName {get;set;}
    }
}