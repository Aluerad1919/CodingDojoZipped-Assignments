from django.urls import path
from . import views

urlpatterns = [
    path('', views.book_index),
    path('author_index', views.author_index),
    path('book_details/<int:value>', views.book_details),
    path('author_details/<int:value>', views.author_details),
    path('post_book', views.add_book),
    path('post_author', views.add_author),
    path('new_author_to_book/<book_id>', views.add_author_to_book),
    path('new_book_to_author/<author_id>', views.add_book_to_author),
]