from django.shortcuts import render, redirect
from .models import *

def book_index(request):
    context = {
        'Books_Db' : Books.objects.all()

    }
    return render(request, 'book_index.html', context)

def author_index(request):
    context = {
        'Authors_Db' : Authors.objects.all()
    }
    return render (request, 'author_index.html', context)

def book_details(request, value):
    context = {
        'this_book' : Books.objects.get(id = value),
        'Authors_excluded' : Authors.objects.exclude(got_published=Books.objects.get(id=value))
    }
    return render (request, 'book_details.html', context)

def author_details(request, value):
    context = {
        'this_author' : Authors.objects.get(id= value),
        'Books_excluded' : Books.objects.exclude(published_work=Authors.objects.get(id=value))
    }
    return render(request, 'author_details.html', context)

def add_book(request):
    Books.objects.create(
        title=request.POST['title_input'],
        synopsis = request.POST['desc_input']
    )
    return redirect('/')

def add_author(request):
    Authors.objects.create(
        first_name = request.POST['fname_input'],
        last_name = request.POST['lname_input'],
        notes = request.POST['bio_input']
    )
    return redirect('/author_index')

def add_book_to_author(request, author_id):
    this_book = Books.objects.get(id= request.POST['another_book'])
    this_author = Authors.objects.get(id = author_id)
    this_author.got_published.add(this_book)
    return redirect(f"/author_details/{this_author.id}")

def add_author_to_book(request, book_id):
    this_book = Books.objects.get(id= book_id)
    this_author = Authors.objects.get(id = request.POST['another_author'])
    this_book.published_work.add(this_author)
    return redirect(f"/book_details/{this_book.id}")