from django.db import models

class Books(models.Model):
    title = models.CharField(max_length=50)
    synopsis = models.TextField(default="N/A")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Authors(models.Model):
    first_name = models.CharField( max_length=50)
    last_name = models.CharField( max_length=50)
    notes = models.TextField(default="N/A")
    got_published = models.ManyToManyField(Books, related_name="published_work")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)