from django.apps import AppConfig


class BooksNAuthorsConfig(AppConfig):
    name = 'Books_n_Authors'
