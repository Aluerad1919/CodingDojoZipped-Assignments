from django.apps import AppConfig


class NinjaLooterConfig(AppConfig):
    name = 'Ninja_looter'
