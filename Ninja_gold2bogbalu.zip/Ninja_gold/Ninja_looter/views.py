from django.shortcuts import render, redirect
from time import localtime, strftime
import random

def index(request):
    if 'gold' not in request.session:
        request.session['gold'] = 0
    if 'action' not in request.session:
        request.session['action'] = []
    context = {
        "gold": request.session['gold'],
        "action": request.session['action']
    }
    return render(request, 'index.html', context)

def process_money(request):
    money = 0
    if request.POST['option'] == "farm":
        money = random.randint(10, 20)
        request.session['gold'] += money

    if request.POST['option'] == "cave":
        money = random.randint(5, 10)
        request.session['gold'] += money

    if request.POST['option'] == "house":
        money = random.randint(2,5)
        request.session['gold'] += money

    if request.POST['option'] == "casino":
        money = random.randint(-50, 50)
        request.session['gold'] += money


    time = strftime("%Y-%m-%d %H:%M %p", localtime())
    if money < 0:
        action = f"{money} was lost....you have {request.session['gold']} gold at {time}" 
    else:   
        action = f"{money}was add to make{request.session['gold']} at {time}"
    request.session['action'].append(action)

    return redirect('/')