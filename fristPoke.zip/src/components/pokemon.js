import React,{useState, useEffect} from 'react'

const Pokemon = (props) => {
    const [pokemon , setPokemon] = useState([])
    

    const getPokemon = ()=>{
        fetch("https://pokeapi.co/api/v2/pokemon?limit=807")
            // .then(response => response.json())
            // .then(response => setState(response.results))
            .then(response=>{
                return response.json()
            })
            .then(response=> {setPokemon
                (response.results)
            })
    }
    return(
        <div>
            <h1>Pokemon API Fetch</h1>
            <button onClick={getPokemon}>Fetch Pokemon</button>
            {
                pokemon.map((val,i)=>{
                    return(<div key={i}>{val.name}</div>)
                })
            }
            
        </div>
    )
}
export default Pokemon