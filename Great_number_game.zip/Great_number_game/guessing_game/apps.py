from django.apps import AppConfig


class GuessingGameConfig(AppConfig):
    name = 'guessing_game'
