from django.shortcuts import render, redirect
import random

def index(request):
    if 'goal_num' not in request.session:
        request.session ['goal_num'] = random.randint(1, 100)
 
    # context = {
    #     "answer": request.session['answer']
    # }
    return render(request, 'index.html')

def guess(request):
    da_guess = request.POST["guessed_num"]
    if int(da_guess) < request.session['goal_num'] :
        request.session['answer'] = "Too low"
        print("low")
    if int(da_guess) > request.session['goal_num'] :
        request.session['answer'] = "Too High"
        print("high")
    if int(da_guess) == request.session['goal_num']:
        request.session['answer'] = "Correct"
        print("sweet charitot")

    return redirect('/')
