from django.apps import AppConfig


class AppwallConfig(AppConfig):
    name = 'AppWall'
