using System;
using System.ComponentModel.DataAnnotations;
namespace DSwM2
{

    public class Survey
    {
        [Required]
        [MinLength(2)]
        public string UserName{ get; set;}
         [Required]
        [MinLength(3)]
        public string Dojo{ get; set;}
         [Required]
        [MinLength(2)]
        public string FavLangauge{ get; set;}
        [MaxLength(20)]
        public string Comments{ get; set;}
    }
}