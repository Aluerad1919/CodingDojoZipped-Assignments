﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DSwM2.Models;

namespace DSwM2.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet("")]       
        public ViewResult Index()
        {
            return View();
        }
        [HttpPost("register")]
        public IActionResult Register(Survey yourSurvey)
        {
            if(ModelState.IsValid)
            {
                Console.WriteLine("Model worked");
                return RedirectToAction("Survey", yourSurvey);
            }
                Console.WriteLine("Model did not worked");
                return View("Index");
        }
        [HttpGet("Survey")]
        public IActionResult Survey(Survey yourSurvey)
        {
            ViewBag.Name = yourSurvey.UserName;
            ViewBag.Location = yourSurvey.Dojo;
            ViewBag.Favorite = yourSurvey.FavLangauge;
            ViewBag.Comment = yourSurvey.Comments;
            return View();
        }
    }
}
